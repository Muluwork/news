package com.company;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.Console;
import java.io.IOException;

public class Main {

    public static void main(String[] args) {
        scrapper grabber = new scrapper();
        String [] title = grabber.getNews();



	// write your code here

        System.setProperty("WebDriver.chrome.driver", "path to chrome driver");
        WebDriver driver = new ChromeDriver();
//        WebDriver driver1 =new ChromeDriver();
        String cwd;
        try{
            cwd = new java.io.File(".").getCanonicalPath();
        }catch (IOException e){
            cwd = "";
        }
        driver.get(cwd+"/selenium.html");
//        driver.get("http://localhost:8888/");
        System.out.println("Page Title :"+driver.getTitle());
        System.out.println("Current URL: "+driver.getCurrentUrl());
        System.out.println("Length of page source"+driver.getPageSource().toString().length());



        // go to grabbing

//        driver1.get("https://addisfortune.net/");


//        driver1.navigate().refresh();

//        WebElement newElement = driver1.findElement(By.id("addisfortune-main")).findElement(By.className("row")).findElement(By.className("span6")).findElement(By.className("row")).findElement(By.className("span6"));
//        String news = newElement.getText();

//         String[] title = news.split("\n");
        try {
            Thread.sleep(2000);


        }catch (Exception e){}
        driver.navigate().refresh();

       // driver.findElement(By.id("add")).click();
        for(int i=0; i < title.length/4; i++){

            if((i%2) ==0 || i==0){
                driver.findElement(By.id("add")).click();
                driver.findElement(By.id("nTitle")).sendKeys(title[i]);
                continue;
            }
                driver.findElement(By.id("detail")).sendKeys(title[i]);
                driver.findElement(By.id("post")).click();


            }

      }





    }

