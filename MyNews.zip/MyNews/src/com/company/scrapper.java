package com.company;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.ArrayList;

public class scrapper {
    public static String[] title;

    public scrapper(){
        System.setProperty("WebDriver.chrome.driver", "path to chrome driver");
        WebDriver driver = new ChromeDriver();
        driver.get("https://addisfortune.net/");
        try {
            Thread.sleep(7000);

        }catch (Exception e){}
        driver.navigate().refresh();

        WebElement newElement = driver.findElement(By.id("addisfortune-main")).findElement(By.className("row")).findElement(By.className("span6")).findElement(By.className("row")).findElement(By.className("span6"));
        String news = newElement.getText();

    title = news.split("\n");

    }
    public String[] getNews(){
        return title;
    }

}
